from django.contrib import admin
from .models import BookModel

class BooksAdmin(admin.ModelAdmin):
    list_display = ('id','book_name','author_name','pages','prise','released_date')

admin.site.register(BookModel,BooksAdmin)

