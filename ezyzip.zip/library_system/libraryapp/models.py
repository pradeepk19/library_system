from django.db import models
from django.contrib.auth.models import User

class BookModel(models.Model):
    book_name = models.CharField(max_length=30)
    author_name = models.CharField(max_length=30)
    pages = models.IntegerField()
    prise = models.FloatField(max_length=30,null=True)
    released_date = models.DateField(max_length=31)


    def __str__(self):
        return self.book_name




